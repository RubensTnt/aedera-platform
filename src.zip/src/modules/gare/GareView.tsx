import React from "react";

export const GareView: React.FC = () => {
  return (
    <div>
      <h2>View: Gare / Tariffazione</h2>
      <p>Qui vedremo P.O., tariffe, mapping codice tariffa ⇄ modello.</p>
    </div>
  );
};
