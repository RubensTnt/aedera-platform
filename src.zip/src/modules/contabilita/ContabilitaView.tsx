import React from "react";

export const ContabilitaView: React.FC = () => {
  return (
    <div>
      <h2>View: Contabilità / SAL</h2>
      <p>Qui avremo snapshot quantità, SAL e scostamenti.</p>
    </div>
  );
};
