import React from "react";

export const DirezioneTecnicaView: React.FC = () => {
  return (
    <div>
      <h2>View: Direzione Tecnica / KPI</h2>
      <p>Qui vedremo costi, margini e indicatori di progetto.</p>
    </div>
  );
};
