import React from "react";

export const ProgettazioneView: React.FC = () => {
  return (
    <div>
      <h2>View: Progettazione (QA/QC)</h2>
      <p>Qui andranno i pannelli per clash, regole proprietà, ecc.</p>
    </div>
  );
};
