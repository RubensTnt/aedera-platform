import React from "react";

export const ProgrammazioneView: React.FC = () => {
  return (
    <div>
      <h2>View: Programmazione / Avanzamento</h2>
      <p>Qui ci sarà la parte 4D: attività, ordini, stato avanzamento.</p>
    </div>
  );
};
