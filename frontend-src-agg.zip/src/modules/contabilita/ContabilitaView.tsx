// src/modules/contabilita/ContabilitaView.tsx

import React from "react";
import { PoGrid } from "@ui/po/PoGrid";

export const ContabilitaView: React.FC = () => {
  return (
    <div className="h-full">
      <PoGrid />
    </div>
  );
};
